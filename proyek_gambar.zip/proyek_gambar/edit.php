<?php
include "koneksi.php";

$no = $_GET['no'];
$sql = "SELECT * FROM post WHERE no = '$no' ";
$query = mysqli_query($koneksi, $sql);
while ($post = mysqli_fetch_assoc($query)) {
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Edit Postingan</title>
</head>
<body>
<nav class="navbar navbar-expand-lg bg-light" data-bs-theme="light">
    <div class="container-fluid">
    <img src="sefrianf.png" width = "50px" alt=""> 
    <a class="navbar-brand" href=""><i class="" style="font-size:36px"></i></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor03" aria-controls="navbar-Color03" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
        <a class="nav-link disabled" href="#" aria-disabled="true" color="light">ARCHIVEANF</a>

        <div class="collapse navbar-collapse" id="navbar-light">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">

                </li>
            </ul>
            <form class="d-flex">
                <a href="tambah.php" class= "btn btn-primary"> <i class="fa fa-plus" style="font-size:20px"></i>Tambah</a>
                <a href="logout.php" class= "btn btn-outline-seccondary">Logout</a>
            </form>
        </div>
</nav>
<div class="container"></div>
    <h3>Edit Postingan</h3>
    <form action="proses_edit.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="no" class="form-control" value="<?= $post['no'] ?>">
        <input type="hidden" name="foto_lama" class="form-control" value="<?= $post['foto'] ?>">
        
        <label for="gambar" class="form-label">Gambar</label>
        <input type="file" name="gambar" id="" class="form-control" value="<?= $post['gambar'] ?>" ><br><br>

        <img src="images/<?= $post['gambar'] ?>" width="100" alt="" ><br>

        <label for="caption" class="form-label">Caption</label>
        <input type="text" name="caption" id="" class="form-control" value="<?= $post['caption'] ?>" autocomplete="off"><br>

        <label for="lokasi" class="form-label">Lokasi</label>
        <input type="text" name="lokasi" id="" class="form-control" value="<?= $post['lokasi'] ?>" autocomplete="off"><br>
        
        <input type="submit" value="Update" name="update" class="btn btn-secondary">
        <a href="index.php" class="btn btn-dark">Kembali</a>
    </form>
</body>
</html>

<?php } ?>