<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <link rel="icon" type="images/x-icon" href="sefrianf.png" width="30%">
  <title>Login</title>
</head>
<center>
<body>
  <style>
    body {
      background: #E5CFF7;
    background-position: absolute;
    background-size: 260px
    }
    
  </style>
  <div class="container">
    <div class="col-md-4">
      <div class="card" style="margin-top:100px">
      <div class="card-header">
      <img src="sefri.png" witdh="200" height="250">
      <div class="car-body">
  

  <div class="form-group" >
  <form action="proses_login.php" method="post">
    <label for="">Username</label><br>
    <input type="text" name="username" id="" class="form-control"><br>

    <div class="form-group">
    <label for="">Pasword</label><br>
    <input type="password" name="password" id="" class="form-control"><br><br>

    <div class="form-group"></div>
    <input type="submit" value="Login" class="btn btn-secondary btn-block">
  </form>
  </div>
  </div>
</body>
</center>
</html>