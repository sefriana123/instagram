<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Tambah Postingan</title>
</head>
<body>
    <nav class="navbar navbar-expand-lg bg-light" data-bs-theme="light">
    <div class="container-fluid">
    <img src="sefri.png" width = "50px" alt=""> 
    <a class="nav-link disabled" href="#" aria-disabled="true" color="light">ARCHIVEANF</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor03" aria-controls="navbar-Color03" aria-expanded="false" aria-label="Toggle navigation">

        </button>
        <div class="collapse navbar-collapse" id="navbarColor03">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">

                </li>
            </ul>
            <form class="d-flex">
            <a class="btn btn-outline-primary me-2" data-bs-toggle="modal" data-bs-target="#staticBackdrop"><i class="fa fa-plus"></i></button>
                <a href="logout.php" class= "btn btn-outline-secondary"><i class="fa fa-close"></i></a>
            </form>
        </div>
</nav>
<br>
<div class="container">
    <h3>Tambah Postingan</h3>
    <form action="proses_tambah.php" method="post" enctype="multipart/form-data">
        <label for="gambar" class="form-label">Gambar</label><br>
        <input type="file" name="gambar" id=""  class="form-control"><br>

        <label for="caption" class="form-label">Caption</label><br>
        <input type="text" name="caption" id="" class="form-control"><br>

        <label for="lokasi" class="form-label">Lokasi</label><br>
        <input type="text" name="lokasi" id=""  class="form-control"><br><br>

        <input type="submit" value="Simpan" name="simpan" class="btn btn-secondary">
        <a href="index.php" class="btn btn-dark">kembali</a>
    </form>
    </div>
</body>
</html>