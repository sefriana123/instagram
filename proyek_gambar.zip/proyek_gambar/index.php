<?php 
session_start();

if (!isset($_SESSION['login'])) {
  header("location:login.php?pesan=logindulu");
}


include "koneksi.php";
$sql = "SELECT * FROM post order by no desc";
$query = mysqli_query($koneksi,$sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="icon" type="images/x-icon" href="sefrianf.png" width="30%">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    <title>archiveanf</title>
</head>
<body>
<style>
.zoom {
  transition: transform .2s; /* Animation */
  
  margin: 0 auto;
}

.zoom:hover {
  transform: scale(1.2); /* (150% zoom - Note: if the zoom is too large, it will go outside of the viewport) */
}

body {
    background-image: url('purple.jpg');
    background-position: absolute;
    background-size: 260px
}
</style>
<nav class="navbar fixed-top navbar-expand-lg bg-light sticky-top" data-bs-theme="light">
<img src="sefrianf.png" width ="80px" height="80px" style="margin-left: 30px;" alt="">     
<div class="container-fluid">
<a class="nav-link disabled" href="#" aria-disabled="true" color="light">ARCHIVEANF</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor03" aria-controls="navbar-Color03" aria-expanded="false" aria-label="Toggle navigation">

        </button>
        <div class="collapse navbar-collapse" id="navbarColor03">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">

                </li>
            </ul>
            <form class="d-flex">
            <a class="btn btn-outline-primary me-2" data-bs-toggle="modal" data-bs-target="#staticBackdrop"><i class="fa fa-plus"></i>Tambah</button>
                <a href="logout.php" class= "btn btn-outline-secondary"><i class="fa fa-close"></i>Logout</a>
            </form>
        </div>
</nav>
    <h1 align = "center"></h1>
    <div class="row">
    <?php while ($post=mysqli_fetch_assoc($query)) { ?>
<center>   
    <div class="card" style="width: 18rem;">
    <div class="zoom">
    <img class="card-img-top" src="images/<?= $post['gambar'] ?>" alt="Card image cap">
    <div class="card-body">
        <h5 class="caption"><?= $post['caption'] ?></h5>
        <p class="lokasi"><?= $post['lokasi'] ?></p>

    <a href="hapus.php?no=<?= $post['no'] ?>" class="btn btn-primary"><i class="fa fa-trash" style="font-size:20px"></i></a>
    <button class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#staticBackdrop<?=$post['no']?>"><i class="fa fa-edit"></i></button>
    </div>
    </div>
    </div> <br>
    <!-- Modal -->
 <div class="modal fade" id="staticBackdrop<?=$post['no']?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header" style="background-color: #DFCCFB;">
                    <h1 class="modal-title fs-5" id="staticBackdropLabel">EDIT POSTINGAN</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="container" align="left">
                <form action="proses_edit.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="no" value="<?= $post['no'] ?>">
        <input type="hidden" name="gambar_lama" value="<?= $post['gambar'] ?>" class="form-control">
        <br>
        <label for="">Gambar</label>
        <input type="file" name="gambar" id="" value="<?= $post['gambar'] ?>" class="form-control"><br>
        <img src="images/<?= $post['gambar'] ?>" width="100" alt=""><br><br>
        <label for="">Caption</label>
        <input type="text" name="caption" id="" value="<?= $post['caption'] ?>" class="form-control" autocomplete="off"><br>
        <label for="">Lokasi</label>
        <input type="text" name="lokasi" id="" value="<?= $post['lokasi'] ?>" class="form-control" autocomplete="off"><br>
        <div align="right">
        <input type="submit" value="Update" name="update" class="btn btn-primary"><br>
        </div>
    </form>
    <div class="modal-footer">
    </div>
    </div>
            </div>
        </div>
</div>
<?php } ?>
    </div>

    <!-- Modal -->
   <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="staticBackdropLabel">Form Tambah Postingan</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="proses_tambah.php" method="post" enctype="multipart/form-data">
                <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Gambar</label>
                            <input type="file" name="gambar" id="" required class="form-control">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Caption</label>
                            <input type="text" name="caption" id="" class="form-control"><br>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Lokasi</label>
                            <input type="text" name="lokasi" id="" class="form-control"><br>
                        </div>                    
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary" name="simpan">Simpan</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </form>
            </div>
        </div>
    </div>
</body>
</html>